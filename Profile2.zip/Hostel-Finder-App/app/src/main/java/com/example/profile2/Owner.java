package com.example.profile2;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class Owner extends AppCompatActivity {
    Button addHostel, SignOut;
    String Username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner);
        addHostel = findViewById(R.id.AddHostel);
        Intent i = getIntent();
        Username = (String) i.getSerializableExtra("Username");
        addHostel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Owner.this, AddHostelActivity.class);
                intent.putExtra("Username", (String) Username);
                startActivity(intent);
            }
        });
        SignOut = findViewById(R.id.Signout);
        SignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent I = new Intent(Owner.this, SignInActivity.class);
                startActivity(I);
                finish();
            }
        });
    }
}

