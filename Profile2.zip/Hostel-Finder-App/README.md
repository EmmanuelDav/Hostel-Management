# Hostel-Finder-App
An Android app that allows hostel/flat owners to add their hostels/flats respectively on firebase and displays hostel/flat to the user

The  app has 2 login one for hostel Owner and one for the student/user.
The app pin points the corresponding hostel location on the map and the user can navigate to the hostel location using google map
Used Firebase Cloud Firestore and Firebase Auth.
 
 Dependency Used:
 Glide,
  Google MapFirebase,
  de.hdodenhof:circleimageview:3.0.1.
 
